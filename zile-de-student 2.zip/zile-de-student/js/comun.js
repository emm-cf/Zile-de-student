/* =========================================================
   ZILE DE STUDENT · comun.js
   Bucăți folosite și de aplicația elevului (index.html),
   și de pagina echipei (echipa.html):
   - formatarea numerelor și a datelor
   - codul de raport (ZDS1.…) pe care elevul îl trimite echipei
   - graficul de evoluție (desenat în SVG, fără biblioteci)
   ========================================================= */
const ZDS = (function () {
  "use strict";

  const fmt = (n, d = 0) => Number(n).toLocaleString("ro-RO", { minimumFractionDigits: d, maximumFractionDigits: d });
  const z2 = (x) => String(x).padStart(2, "0");
  const dateStr = (d = new Date()) => d.getFullYear() + "-" + z2(d.getMonth() + 1) + "-" + z2(d.getDate());
  function toDate(s) { const [y, m, d] = s.split("-").map(Number); return new Date(y, m - 1, d); }
  const DAY = 24 * 60 * 60 * 1000;
  const addDays = (s, n) => dateStr(new Date(toDate(s).getTime() + n * DAY));
  const daysBetween = (a, b) => Math.round((toDate(b) - toDate(a)) / DAY);
  const shortDate = (s) => { const [, m, d] = s.split("-"); return d + "." + m; };

  /* ---------- codul de raport ----------
     Tot raportul elevului, într-un singur „cuvânt” fără spații,
     virgule sau ghilimele, ca să treacă neatins prin Google Forms și CSV. */
  function encode(obj) {
    const json = JSON.stringify(obj);
    const b64 = btoa(unescape(encodeURIComponent(json)));
    return "ZDS1." + b64.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }
  function decode(code) {
    let b = code.replace(/^ZDS1\./, "").replace(/-/g, "+").replace(/_/g, "/");
    while (b.length % 4) b += "=";
    return JSON.parse(decodeURIComponent(escape(atob(b))));
  }
  function findReports(text) {
    const out = [];
    const re = /ZDS1\.[A-Za-z0-9_-]{10,}/g;
    let m;
    while ((m = re.exec(text))) { try { out.push(decode(m[0])); } catch (e) { /* cod stricat, îl sărim */ } }
    return out;
  }

  // Transformă o listă de [dată, sumă] într-o serie cumulată, zi de zi, între from și to.
  function cumulative(events, from, to) {
    const per = {};
    events.forEach(([d, v]) => { per[d] = (per[d] || 0) + v; });
    const out = [];
    let sum = 0;
    for (let d = from; d <= to; d = addDays(d, 1)) {
      sum += per[d] || 0;
      out.push([d, sum]);
      if (out.length > 400) break;
    }
    return out;
  }

  /* ---------- graficul ----------
     series: [{ name, color, points: [[ "2026-11-25", 120 ], ...] }]
     Toate seriile au aceleași date pe axa de jos. */
  function chart(el, series, opts = {}) {
    const W = opts.width || 340, H = opts.height || 190, L = 44, R = 10, T = 12, B = 26;
    const pts = series[0] ? series[0].points : [];
    el.innerHTML = "";
    if (pts.length < 1) { el.textContent = "Încă nu sunt date pentru grafic."; return; }
    let max = 0;
    series.forEach((s) => s.points.forEach((p) => { if (p[1] > max) max = p[1]; }));
    max = niceMax(max || 1);
    const n = Math.max(1, pts.length - 1);
    const x = (i) => L + ((W - L - R) * i) / n;
    const y = (v) => T + (H - T - B) * (1 - v / max);
    const ns = "http://www.w3.org/2000/svg";
    const svg = document.createElementNS(ns, "svg");
    svg.setAttribute("viewBox", "0 0 " + W + " " + H);
    svg.setAttribute("class", "chart");
    svg.setAttribute("role", "img");
    svg.setAttribute("aria-label", opts.label || "Grafic");
    const add = (tag, attrs, text) => {
      const e = document.createElementNS(ns, tag);
      for (const k in attrs) e.setAttribute(k, attrs[k]);
      if (text != null) e.textContent = text;
      svg.appendChild(e);
      return e;
    };
    // linii orizontale + valori
    for (let k = 0; k <= 4; k++) {
      const v = (max * k) / 4;
      add("line", { x1: L, x2: W - R, y1: y(v), y2: y(v), class: "grid" });
      add("text", { x: L - 6, y: y(v) + 4, "text-anchor": "end", class: "tick" }, fmtShort(v));
    }
    // date jos: prima, mijloc, ultima
    const idx = pts.length > 2 ? [0, Math.floor((pts.length - 1) / 2), pts.length - 1] : pts.map((_, i) => i);
    idx.forEach((i, k) => add("text", {
      x: x(i), y: H - 6, class: "tick",
      "text-anchor": k === 0 ? "start" : k === idx.length - 1 ? "end" : "middle"
    }, shortDate(pts[i][0])));
    // seriile (ca trepte: suma crește în ziua depunerii)
    series.forEach((s) => {
      let d = "";
      s.points.forEach((p, i) => {
        d += i === 0 ? "M" + x(0) + "," + y(p[1]) : "H" + x(i) + "V" + y(p[1]);
      });
      if (s.points.length === 1) d += "H" + (W - R);
      if (s.fill) add("path", { d: d + "V" + y(0) + "H" + x(0) + "Z", fill: s.color, opacity: ".12", stroke: "none" });
      add("path", { d, fill: "none", stroke: s.color, "stroke-width": 2.5, "stroke-linejoin": "round", "stroke-linecap": "round", ...(s.dash ? { "stroke-dasharray": "5 4" } : {}) });
      const last = s.points[s.points.length - 1];
      add("circle", { cx: s.points.length === 1 ? W - R : x(s.points.length - 1), cy: y(last[1]), r: 3.5, fill: s.color });
    });
    el.appendChild(svg);
    // legenda
    const leg = document.createElement("div");
    leg.className = "chart-legend";
    series.forEach((s) => {
      const it = document.createElement("span");
      const sw = document.createElement("i");
      sw.style.background = s.color;
      const last = s.points[s.points.length - 1][1];
      it.append(sw, s.name + ": " + fmt(last) + " lei");
      leg.appendChild(it);
    });
    el.appendChild(leg);
  }
  function niceMax(v) {
    const p = Math.pow(10, Math.floor(Math.log10(v)));
    for (const m of [1, 2, 2.5, 5, 10]) if (m * p >= v) return m * p;
    return 10 * p;
  }
  function fmtShort(v) {
    if (v >= 10000) return fmt(v / 1000, v % 1000 ? 1 : 0) + "k";
    return fmt(v);
  }

  return { fmt, dateStr, addDays, daysBetween, shortDate, encode, decode, findReports, cumulative, chart };
})();
