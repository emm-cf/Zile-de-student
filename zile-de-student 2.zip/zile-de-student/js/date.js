/* =========================================================
   ZILE DE STUDENT · date.js
   Aici sunt TOATE cifrele și textele pe care echipa le poate
   schimba fără să umble la restul codului.
   ========================================================= */

/* --- 1. SETĂRI PENTRU ECHIPĂ ---------------------------------- */
const CONFIG = {
  // Câți elevi participă.
  NR_ELEVI: 100,
  // Obiectivul comun al liceului, în zile de student (300 = un an universitar).
  LICEU_OBIECTIV: 300,

  // Linkul către formularul (de ex. Google Forms) în care elevii
  // lipesc raportul. Dacă e gol, butonul doar copiază textul.
  LINK_FORMULAR: "",

  // Banca parteneră: elevul depune banii puși deoparte în contul lui
  // personal de la această bancă și scrie codul lui la „detalii plată”.
  BANCA_NUME: "banca parteneră",
  // Ce scrie elevul la detaliile depunerii, înainte de codul lui.
  PREFIX_COD: "ZDS-",

  // Câte zile are provocarea.
  ZILE_PROVOCARE: 30,
  // Câte ore trebuie să aștepte un produs pus „pe gânduri”.
  ORE_ASTEPTARE: 24
};

/* --- 1b. STATISTICILE TUTUROR ELEVILOR -------------------------- */
// NU le scrie de mână: le generează pagina echipei (echipa.html),
// butonul „Copiază statisticile pentru site”. Lipește-le aici în locul
// blocului de mai jos și publică din nou site-ul.
const STATISTICI_LICEU = {
  actualizat: "",
  participanti: 0,
  declarat: 0,
  verificat: 0,
  zile: 0,
  serie: []
};

/* --- 2. COSTURILE ORAȘELOR ------------------------------------- */
// Din calculatorul „Facultatea mea”, foaia „Comparatie”
// (cursul BNR din 19.11.2026). Lei pe lună: [la cămin, în chirie la comun].
// Fără taxa de școlarizare.
const ORASE = {
  "București": [1810, 3110],
  "Cluj-Napoca": [1550, 3100],
  "Iași": [1560, 2410],
  "Timișoara": [1560, 2660],
  "Brașov": [1560, 2560],
  "Constanța": [1510, 2310],
  "Amsterdam": [6199, 7268],
  "Milano": [5301, 6370],
  "Madrid": [6306, 5638],
  "Londra": [9590, 9909],
  "Paris": [4302, 7241],
  "Berlin": [3848, 5451],
  "Stockholm": [5033, 5752],
  "SUA (univ. publică)": [8837, 9322]
};

// Lunile anului universitar (10 luni x 30 de zile = 300 de zile).
const LUNI = ["Oct", "Noi", "Dec", "Ian", "Feb", "Mar", "Apr", "Mai", "Iun", "Iul"];

/* --- 3. MESAJELE DE LA „TINE, STUDENT” -------------------------- */
// Fiecare mesaj se deblochează în ziua scrisă la „zi”.
// Poți folosi în text:
//   {oras}    orașul ales
//   {zi_lei}  cât costă o zi de student acolo
//   {strans}  cât a strâns elevul până acum, în zile
//   {lei}     cât a strâns elevul până acum, în lei
//   {tinta}   ținta lui, în zile
const MESAJE = [
  { zi: 1,  text: "Salut! Sunt eu, tu din primul an de facultate, în {oras}. Aici o zi mă costă {zi_lei} lei: cămin, mâncare, transport. Fiecare zi pe care o strângi acum e o zi în care nu stau cu grija banilor." },
  { zi: 3,  text: "Un sfat de la mine: înainte să cumperi ceva, scrie prețul în „Cât costă?”. Nu ca să te oprești. Doar ca să vezi cât înseamnă pentru mine." },
  { zi: 5,  text: "Până acum ai strâns {strans}. Pentru mine asta înseamnă mese calde și drumuri la facultate fără să număr fiecare leu." },
  { zi: 7,  text: "O săptămână! Ținta ta e {tinta}. Nu trebuie să fie perfect, trebuie doar să continui." },
  { zi: 10, text: "Știi ce costă aici cât un energizant? Cam o pătrime dintr-o zi de-a mea. Nu zic să nu-l mai iei. Zic doar să știi." },
  { zi: 14, text: "Două săptămâni. Ai pus deoparte {lei} lei, adică {strans} de student în {oras}. Eu le simt pe toate." },
  { zi: 17, text: "Butonul „Aștept 24 h” e preferatul meu. De cele mai multe ori, a doua zi nici nu mai vrei lucrul acela." },
  { zi: 21, text: "Jumătate din colegii mei de cămin au rămas fără bani în luna a șaptea. Eu încerc să nu fiu unul dintre ei. Tu ce ai amânat săptămâna asta?" },
  { zi: 25, text: "Mai sunt 5 zile. Uită-te în calendar: fiecare pătrățel galben e o zi din viața mea pe care mi-ai dat-o deja." },
  { zi: 28, text: "Aproape gata. Peste două zile îți scriu o scrisoare. Până atunci, mai alege o dată „pun deoparte”." }
];
