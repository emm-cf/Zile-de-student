/* =========================================================
   ZILE DE STUDENT · echipa.js
   Pagina echipei: citește rapoartele elevilor și extrasul
   băncii, le compară și face raportul. Totul se întâmplă în
   browser; nimic nu e trimis sau salvat.
   ========================================================= */
(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const fmt = ZDS.fmt;
  const TOL = 0.5; // diferență acceptată, în lei

  let reports = [];   // rapoartele elevilor (cel mai nou pe cod)
  let bank = null;    // { header, rows }
  let students = [];  // rezultatul comparației
  let selected = null;

  /* ---------- citirea fișierelor ---------- */
  function parseCSV(text) {
    text = text.replace(/^﻿/, "");
    const first = text.split(/\r?\n/)[0] || "";
    const cnt = (ch) => first.split(ch).length - 1;
    const sep = [";", ",", "\t"].sort((a, b) => cnt(b) - cnt(a))[0];
    const rows = []; let row = [], cell = "", q = false;
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (q) {
        if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; }
        else cell += c;
      } else if (c === '"') q = true;
      else if (c === sep) { row.push(cell); cell = ""; }
      else if (c === "\n" || c === "\r") {
        if (c === "\r" && text[i + 1] === "\n") i++;
        row.push(cell); rows.push(row); row = []; cell = "";
      } else cell += c;
    }
    if (cell !== "" || row.length) { row.push(cell); rows.push(row); }
    return rows.filter((r) => r.some((x) => x.trim() !== ""));
  }
  function num(s) {
    s = String(s || "").replace(/[^\d,.\-]/g, "");
    if (!s) return NaN;
    const c = s.lastIndexOf(","), d = s.lastIndexOf(".");
    if (c > -1 && d > -1) s = c > d ? s.replace(/\./g, "").replace(",", ".") : s.replace(/,/g, "");
    else if (c > -1) s = s.replace(",", ".");
    return parseFloat(s);
  }
  function date(s) {
    s = String(s || "").trim();
    let m = s.match(/(\d{4})-(\d{1,2})-(\d{1,2})/);
    if (m) return m[1] + "-" + m[2].padStart(2, "0") + "-" + m[3].padStart(2, "0");
    m = s.match(/(\d{1,2})[./-](\d{1,2})[./-](\d{4})/);
    if (m) return m[3] + "-" + m[2].padStart(2, "0") + "-" + m[1].padStart(2, "0");
    return "";
  }
  const readFile = (f) => new Promise((ok, no) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = no; r.readAsText(f); });

  function loadReports(text) {
    const all = ZDS.findReports(text);
    const byId = {};
    all.forEach((r) => { if (r && r.i && (!byId[r.i] || r.d >= byId[r.i].d)) byId[r.i] = r; });
    reports = Object.values(byId);
    $("repInfo").textContent = all.length
      ? "Am găsit " + (all.length === 1 ? "un raport" : all.length + " rapoarte") + ", de la " + (reports.length === 1 ? "un elev." : reports.length + " elevi.")
      : "Nu am găsit niciun raport în fișier.";
    update();
  }

  function loadBank(text) {
    const rows = parseCSV(text);
    if (rows.length < 2) { $("bankInfo").textContent = "Fișierul pare gol."; bank = null; update(); return; }
    const header = rows[0].map((h) => h.trim());
    bank = { header, rows: rows.slice(1) };
    const opts = (sel, guess) => {
      sel.innerHTML = "";
      header.forEach((h, i) => { const o = document.createElement("option"); o.value = i; o.textContent = h || "coloana " + (i + 1); sel.appendChild(o); });
      const g = header.findIndex((h) => guess.test(h));
      sel.value = g > -1 ? g : 0;
    };
    opts($("colDate"), /dat/i);
    opts($("colSum"), /sum|amount|credit|valoare|lei/i);
    $("bankCols").hidden = false;
    $("bankInfo").textContent = "Am citit " + bank.rows.length + " rânduri din extras.";
    update();
  }

  /* ---------- comparația ---------- */
  function compare() {
    const prefix = CONFIG.PREFIX_COD.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const codeRe = new RegExp(prefix + "\\s*([A-Z0-9]{6})", "i");
    const byId = {};
    reports.forEach((r) => {
      byId[r.i] = {
        r, id: r.i, code: CONFIG.PREFIX_COD + r.i,
        saved: r.e.reduce((s, e) => s + e[1], 0),
        declared: r.b.reduce((s, b) => s + b[1], 0),
        verified: 0, bankRows: []
      };
    });
    // referințele declarate de elevi, ca a doua cale de potrivire
    const refs = {};
    reports.forEach((r) => r.b.forEach((b) => { if (b[2] && b[2].length >= 4) refs[b[2].toUpperCase()] = r.i; }));

    const orphans = [];
    if (bank) {
      const ci = +$("colDate").value, si = +$("colSum").value;
      bank.rows.forEach((row) => {
        const sum = num(row[si]);
        if (!(sum > 0)) return; // retragerile și rândurile fără sumă nu contează
        const d = date(row[ci]);
        const text = row.join(" ").toUpperCase();
        let id = null;
        const m = text.match(codeRe);
        if (m && byId[m[1].toUpperCase()]) id = m[1].toUpperCase();
        if (!id) for (const ref in refs) if (text.includes(ref)) { id = refs[ref]; break; }
        const item = { d, sum, text: row.join(" · ") };
        if (id) { byId[id].verified += sum; byId[id].bankRows.push(item); }
        else orphans.push(item);
      });
    }
    students = Object.values(byId).map((s) => {
      s.saved = Math.round(s.saved * 100) / 100;
      s.verified = Math.round(s.verified * 100) / 100;
      if (s.saved <= 0 && s.verified <= 0) s.status = ["fără economii", "p-wait", 3];
      else if (s.verified + TOL >= s.saved) s.status = ["verificat", "p-ok", 4];
      else if (s.declared > s.verified + TOL) s.status = ["declarat, negăsit la bancă", "p-no", 0];
      else if (s.verified > 0) s.status = ["parțial depus", "p-part", 1];
      else s.status = ["nedepus încă", "p-part", 2];
      s.days = s.saved / (s.r.z || 50);
      return s;
    }).sort((a, b) => a.status[2] - b.status[2] || b.saved - a.saved);
    return orphans;
  }

  function overallSeries() {
    let from = null, to = null;
    const ev = [], vb = [];
    students.forEach((s) => {
      if (!from || s.r.s < from) from = s.r.s;
      if (!to || s.r.d > to) to = s.r.d;
      s.r.e.forEach((e) => ev.push(e));
      s.bankRows.forEach((b) => { if (b.d) { vb.push([b.d, b.sum]); if (b.d > to) to = b.d; } });
    });
    if (!from) return null;
    const a = ZDS.cumulative(ev, from, to), b = ZDS.cumulative(vb, from, to);
    return a.map((p, i) => [p[0], Math.round(p[1]), Math.round(b[i][1])]);
  }

  /* ---------- afișarea ---------- */
  function kpi(box, items) {
    box.innerHTML = "";
    items.forEach(([t, v, hl]) => {
      const d = document.createElement("div");
      if (hl) d.className = "hl";
      const b = document.createElement("b"); b.textContent = v;
      d.append(b, t);
      box.appendChild(d);
    });
  }

  function update() {
    $("out").hidden = !reports.length;
    if (!reports.length) return;
    const orphans = compare();
    const tot = (k) => students.reduce((s, x) => s + x[k], 0);
    const saved = tot("saved"), ver = tot("verified"), decl = tot("declared"), days = tot("days");
    const nOk = students.filter((s) => s.status[0] === "verificat").length;
    const nProb = students.filter((s) => s.status[2] === 0).length;
    const nGoal = students.filter((s) => s.saved >= s.r.g).length;
    kpi($("kpis"), [
      ["Participanți cu raport", students.length + " din " + CONFIG.NR_ELEVI],
      ["Puși deoparte (declarat)", fmt(saved) + " lei", true],
      ["Depuși (declarat de elevi)", fmt(decl) + " lei"],
      ["Verificați la bancă", fmt(ver) + " lei", true],
      ["Din economii, verificat", saved ? fmt((Math.min(ver, saved) / saved) * 100) + "%" : "–"],
      ["Zile de student strânse", fmt(days, 1)],
      ["Media pe elev", fmt(saved / students.length) + " lei"],
      ["Și-au atins ținta", nGoal + " elevi"],
      ["Elevi verificați integral", nOk + " elevi"],
      ["Declarații negăsite la bancă", nProb + " elevi"]
    ]);
    const ser = overallSeries();
    ZDS.chart($("allChart"), [
      { name: "Pus deoparte (declarat)", color: "var(--cobalt)", fill: true, points: ser.map((r) => [r[0], r[1]]) },
      { name: "Verificat la bancă", color: "var(--ok)", points: ser.map((r) => [r[0], r[2]]) }
    ], { width: 760, height: 260, label: "Evoluția economiilor tuturor elevilor" });
    $("allNote").textContent = bank
      ? "Linia verde arată doar banii găsiți în extrasul băncii, la data depunerii."
      : "Încarcă și extrasul băncii ca să apară linia cu sumele verificate.";
    renderTable();
    $("orphanCard").hidden = !orphans.length;
    $("orphans").innerHTML = "";
    orphans.forEach((o) => $("orphans").appendChild(li(o.text, fmt(o.sum, 2) + " lei")));
    if (selected) showDetail(selected);
  }

  function li(a, b) {
    const el = document.createElement("li");
    const x = document.createElement("span"); x.textContent = a; el.appendChild(x);
    if (b != null) { const y = document.createElement("span"); y.className = "num"; y.textContent = b; el.appendChild(y); }
    return el;
  }

  function renderTable() {
    const f = $("filter").value;
    const tb = $("table").tBodies[0];
    tb.innerHTML = "";
    students.filter((s) => f === "all" || (f === "ok" ? s.status[0] === "verificat" : s.status[2] <= 2)).forEach((s) => {
      const tr = document.createElement("tr");
      tr.dataset.id = s.id;
      if (s.id === selected) tr.className = "sel";
      const cells = [
        [s.code, "num"], [s.r.c, ""], [fmt(s.saved) + " lei", "r"], [fmt(s.declared) + " lei", "r"],
        [bank ? fmt(s.verified) + " lei" : "–", "r"], [s.saved >= s.r.g ? "atinsă" : fmt(s.r.g) + " lei", "r"]
      ];
      cells.forEach(([t, c]) => { const td = document.createElement("td"); td.textContent = t; td.className = c; tr.appendChild(td); });
      const td = document.createElement("td");
      const pill = document.createElement("span");
      pill.className = "pill " + (bank ? s.status[1] : "p-wait");
      pill.textContent = bank ? s.status[0] : "fără extras";
      td.appendChild(pill); tr.appendChild(td);
      tb.appendChild(tr);
    });
  }

  function showDetail(id) {
    const s = students.find((x) => x.id === id);
    if (!s) { $("detail").hidden = true; return; }
    selected = id;
    $("detail").hidden = false;
    $("dTitle").textContent = s.code + " · " + s.r.c + (s.r.h === "chirie" ? ", în chirie" : ", la cămin");
    kpi($("dKpis"), [
      ["Pus deoparte", fmt(s.saved) + " lei", true],
      ["Depus (declarat)", fmt(s.declared) + " lei"],
      ["Verificat la bancă", bank ? fmt(s.verified) + " lei" : "–", true],
      ["Ținta (30 de zile)", fmt(s.r.g) + " lei"],
      ["Zile de student", fmt(s.days, 1)],
      ["Cumpărături / amânări 24 h", (s.r.k ? s.r.k[0] + " / " + s.r.k[1] : "–")]
    ]);
    let to = s.r.d;
    s.bankRows.forEach((b) => { if (b.d > to) to = b.d; });
    const series = [
      { name: "Pus deoparte", color: "var(--cobalt)", fill: true, points: ZDS.cumulative(s.r.e, s.r.s, to) },
      { name: "Depus (declarat)", color: "var(--gold)", dash: true, points: ZDS.cumulative(s.r.b.map((b) => [b[0], b[1]]), s.r.s, to) }
    ];
    if (bank) series.push({ name: "Verificat la bancă", color: "var(--ok)", points: ZDS.cumulative(s.bankRows.filter((b) => b.d).map((b) => [b.d, b.sum]), s.r.s, to) });
    ZDS.chart($("dChart"), series, { width: 760, height: 240, label: "Evoluția elevului " + s.code });
    // fiecare depunere declarată: o găsim în extras? (aceeași sumă, ±3 zile sau aceeași referință)
    const used = new Set();
    $("dDecl").innerHTML = "";
    if (!s.r.b.length) $("dDecl").appendChild(li("Nicio depunere declarată."));
    s.r.b.forEach(([d, p, ref]) => {
      const k = s.bankRows.findIndex((b, i) => !used.has(i) &&
        ((ref && b.text.toUpperCase().includes(ref.toUpperCase())) ||
         (Math.abs(b.sum - p) <= TOL && b.d && Math.abs(ZDS.daysBetween(b.d, d)) <= 3)));
      if (k > -1) used.add(k);
      const el = li(ZDS.shortDate(d) + " · " + fmt(p, p % 1 ? 2 : 0) + " lei" + (ref ? " · ref. " + ref : ""));
      const pill = document.createElement("span");
      pill.className = "pill " + (!bank ? "p-wait" : k > -1 ? "p-ok" : "p-no");
      pill.textContent = !bank ? "fără extras" : k > -1 ? "găsită" : "negăsită";
      el.appendChild(pill);
      $("dDecl").appendChild(el);
    });
    $("dBank").innerHTML = "";
    if (!s.bankRows.length) $("dBank").appendChild(li(bank ? "Nicio depunere cu codul acestui elev." : "Încarcă extrasul băncii."));
    s.bankRows.forEach((b) => $("dBank").appendChild(li(b.text, fmt(b.sum, 2) + " lei")));
    document.querySelectorAll("#table tbody tr").forEach((tr) => tr.classList.toggle("sel", tr.dataset.id === id));
  }

  /* ---------- exporturi ---------- */
  function download(name, text) {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob(["﻿" + text], { type: "text/csv;charset=utf-8" }));
    a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }
  const csvCell = (v) => { v = String(v); return /[;"\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };

  $("bCsv").onclick = () => {
    const head = ["Cod", "Oras", "Locuinta", "Start", "Ultimul raport", "Pus deoparte (lei)", "Depus declarat (lei)", "Verificat la banca (lei)", "Tinta (lei)", "Tinta atinsa", "Zile de student", "Cumparaturi", "Amanari 24h", "Stare"];
    const rows = students.map((s) => [s.code, s.r.c, s.r.h, s.r.s, s.r.d, fmt(s.saved, 2), fmt(s.declared, 2), bank ? fmt(s.verified, 2) : "",
      fmt(s.r.g), s.saved >= s.r.g ? "da" : "nu", fmt(s.days, 2), s.r.k ? s.r.k[0] : "", s.r.k ? s.r.k[1] : "", bank ? s.status[0] : "fara extras"]);
    download("raport-zile-de-student-" + ZDS.dateStr() + ".csv", [head].concat(rows).map((r) => r.map(csvCell).join(";")).join("\r\n"));
  };

  $("bStats").onclick = async () => {
    const tot = (k) => students.reduce((s, x) => s + x[k], 0);
    const ser = overallSeries() || [];
    const d = new Date();
    const text = "const STATISTICI_LICEU = " + JSON.stringify({
      actualizat: d.getDate() + "." + String(d.getMonth() + 1).padStart(2, "0") + "." + d.getFullYear(),
      participanti: students.length,
      declarat: Math.round(tot("saved")),
      verificat: Math.round(Math.min(tot("verified"), tot("saved"))),
      zile: Math.round(tot("days") * 10) / 10,
      serie: ser
    }) + ";";
    try { await navigator.clipboard.writeText(text); $("outToast").textContent = "Am copiat. În js/date.js, înlocuiește blocul „const STATISTICI_LICEU = { … };” cu ce ai copiat, apoi publică din nou site-ul."; }
    catch (e) { $("outToast").textContent = text; }
  };
  $("bPrint").onclick = () => window.print();

  /* ---------- date de exemplu ---------- */
  function demoData() {
    let seed = 20261125;
    const rnd = () => ((seed = (seed * 1664525 + 1013904223) % 4294967296) / 4294967296);
    const pick = (a) => a[Math.floor(rnd() * a.length)];
    const cities = ["Cluj-Napoca", "Cluj-Napoca", "București", "București", "București", "Iași", "Timișoara", "Brașov", "Constanța", "Berlin", "Milano", "Amsterdam"];
    const ch = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    const reportsOut = [], bankRows = [["Data", "Suma", "Detalii plata", "Referinta"]];
    let trx = 480100;
    for (let n = 0; n < 100; n++) {
      let id = ""; for (let i = 0; i < 6; i++) id += pick(ch);
      const start = ZDS.addDays("2026-10-26", Math.floor(rnd() * 3));
      const pocket = pick([150, 200, 250, 300, 300, 400, 400, 500, 600]);
      const level = pick([0.05, 0.1, 0.1, 0.2]);
      const city = pick(cities);
      const zc = ({ "București": 1810, "Cluj-Napoca": 1550, "Iași": 1560, "Timișoara": 1560, "Brașov": 1560, "Constanța": 1510, "Berlin": 3848, "Milano": 5301, "Amsterdam": 6199 })[city] / 30;
      const zeal = 0.15 + rnd() * 0.5;
      const e = [];
      for (let d = 0; d < 29; d++) if (rnd() < zeal) e.push([ZDS.addDays(start, d), pick([5, 7, 10, 12, 15, 20, 25, 30, 40])]);
      const kind = rnd(); // 0.7 cinstit, 0.15 parțial, 0.1 declară fără să depună, 0.05 nu depune
      const b = [];
      let acc = 0;
      e.forEach(([d, v], i) => {
        acc += v;
        const wk = (x) => Math.floor(ZDS.daysBetween(start, x) / 7);
        const weekEnd = i === e.length - 1 || wk(e[i + 1][0]) !== wk(d);
        if (weekEnd && acc > 0) {
          const dep = kind < 0.85 && kind >= 0.7 ? Math.round(acc * 0.5) : acc;
          const ref = rnd() < 0.5 ? "TRX" + (trx++) : "";
          const dd = ZDS.addDays(d, Math.floor(rnd() * 2));
          if (kind < 0.95) b.push([dd, dep, ref]);
          if (kind < 0.85) bankRows.push([dd.split("-").reverse().join("."), fmt(dep, 2), "Depunere " + (rnd() < 0.93 ? CONFIG.PREFIX_COD + id : "economii"), ref || "TRX" + (trx++)]);
          acc = 0;
        }
      });
      reportsOut.push(ZDS.encode({ i: id, c: city, h: rnd() < 0.7 ? "camin" : "chirie", s: start, d: ZDS.addDays(start, 29), p: pocket, g: Math.round(pocket * level), z: Math.round(zc * 100) / 100, e, b, k: [Math.floor(rnd() * 8), Math.floor(rnd() * 5)] }));
    }
    bankRows.push(["24.11.2026", "-50,00", "Retragere ATM", "TRX999001"]);
    const forms = [["Marcaj de timp", "Lipește aici raportul tău"]].concat(reportsOut.map((c, i) => ["2026/11/" + (20 + (i % 5)) + " 18:00:00", "Zile de student · raport\n" + c]));
    const toCsv = (rows, sep) => rows.map((r) => r.map((v) => { v = String(v); return v.includes(sep) || /["\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }).join(sep)).join("\r\n");
    return { forms: toCsv(forms, ","), bank: toCsv(bankRows, ";") };
  }

  /* ---------- butoane ---------- */
  $("fReports").onchange = async (e) => { if (e.target.files[0]) loadReports(await readFile(e.target.files[0])); };
  $("tReports").oninput = (e) => loadReports(e.target.value);
  $("fBank").onchange = async (e) => { if (e.target.files[0]) loadBank(await readFile(e.target.files[0])); };
  $("colDate").onchange = update;
  $("colSum").onchange = update;
  $("filter").onchange = renderTable;
  $("table").addEventListener("click", (e) => { const tr = e.target.closest("tr[data-id]"); if (tr) { showDetail(tr.dataset.id); $("detail").scrollIntoView({ behavior: "smooth", block: "start" }); } });
  $("bClose").onclick = () => { selected = null; $("detail").hidden = true; renderTable(); };
  $("bDemo").onclick = () => { const d = demoData(); loadReports(d.forms); loadBank(d.bank); $("demoNote").textContent = "Acum vezi date inventate, pentru prezentare. Butonul „Golește” le șterge."; };
  $("bDemoFiles").onclick = () => { const d = demoData(); download("exemplu-raspunsuri-formular.csv", d.forms); setTimeout(() => download("exemplu-extras-banca.csv", d.bank), 400); };
  $("bClear").onclick = () => { reports = []; bank = null; students = []; selected = null; $("bankCols").hidden = true; $("repInfo").textContent = ""; $("bankInfo").textContent = ""; $("fReports").value = ""; $("fBank").value = ""; $("tReports").value = ""; $("detail").hidden = true; update(); };
})();
