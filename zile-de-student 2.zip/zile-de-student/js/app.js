/* =========================================================
   ZILE DE STUDENT · app.js
   Logica aplicației. Datele elevului se salvează doar în
   browserul lui (localStorage), nu pleacă nicăieri.
   ========================================================= */
(function () {
  "use strict";

  const KEY = "zile-de-student-v2";
  const ORA = 60 * 60 * 1000;
  const $ = (id) => document.getElementById(id);

  /* ---------- salvare ---------- */
  let canStore = true;
  function load() {
    try {
      const raw = localStorage.getItem(KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (e) { canStore = false; return null; }
  }
  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { canStore = false; }
  }
  let S = load();
  if (S && !S.deposits) S.deposits = [];
  let showAll = false;

  /* ---------- ajutoare ---------- */
  const fmt = (n, d = 0) => Number(n).toLocaleString("ro-RO", { minimumFractionDigits: d, maximumFractionDigits: d });
  function todayStr(d = new Date()) {
    const z = (x) => String(x).padStart(2, "0");
    return d.getFullYear() + "-" + z(d.getMonth() + 1) + "-" + z(d.getDate());
  }
  function code() {
    const c = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    let s = "";
    for (let i = 0; i < 6; i++) s += c[Math.floor(Math.random() * c.length)];
    return s;
  }
  function monthCost() {
    const c = ORASE[S.city] || ORASE["Cluj-Napoca"];
    return c[S.housing === "chirie" ? 1 : 0];
  }
  const dayCost = () => monthCost() / 30;
  const savedLei = () => S.history.filter((h) => h.a === "save").reduce((s, h) => s + h.p, 0);
  const target = () => Math.max(1, Math.round(S.pocket * S.level));
  const housingText = () => (S.housing === "chirie" ? "în chirie" : "la cămin");

  // Transformă lei în „X zile Y ore” de student.
  function inDays(lei) {
    const ore = Math.round((lei / dayCost()) * 24);
    const z = Math.floor(ore / 24), h = ore % 24;
    const zs = z === 1 ? "o zi" : z + " zile";
    const hs = h === 1 ? "o oră" : h + " ore";
    if (z === 0) return hs;
    if (h === 0) return zs;
    return zs + " " + hs;
  }

  // Ziua provocării (1–30). Pentru prezentări: adaugă ?zi=12 la adresă.
  function dayNum() {
    const forced = parseInt(new URLSearchParams(location.search).get("zi"), 10);
    if (forced > 0) return forced;
    const [y, m, d] = S.start.split("-").map(Number);
    const start = new Date(y, m - 1, d);
    const now = new Date(); now.setHours(0, 0, 0, 0);
    return Math.max(1, Math.round((now - start) / (24 * ORA)) + 1);
  }

  function fill(text) {
    return text
      .replaceAll("{oras}", S.city)
      .replaceAll("{zi_lei}", fmt(dayCost()))
      .replaceAll("{strans}", inDays(savedLei()))
      .replaceAll("{lei}", fmt(savedLei()))
      .replaceAll("{tinta}", inDays(target()));
  }

  function li(textLeft, rightEl) {
    const el = document.createElement("li");
    const s = document.createElement("span");
    s.textContent = textLeft;
    el.appendChild(s);
    if (rightEl) el.appendChild(rightEl);
    return el;
  }
  function btn(label, cls, data) {
    const b = document.createElement("button");
    b.type = "button";
    b.textContent = label;
    b.className = "small " + (cls || "");
    Object.assign(b.dataset, data);
    return b;
  }

  /* ---------- liste de orașe ---------- */
  for (const sel of [$("sCity"), $("city")]) {
    for (const k of Object.keys(ORASE)) {
      const o = document.createElement("option");
      o.value = k; o.textContent = k;
      sel.appendChild(o);
    }
  }
  $("sCity").value = "Cluj-Napoca";

  /* ---------- ecranul de început ---------- */
  $("startForm").addEventListener("submit", (e) => {
    e.preventDefault();
    const pocket = Math.round(parseFloat($("sPocket").value));
    if (!(pocket > 0)) { $("sPocket").focus(); return; }
    S = {
      v: 2, id: code(), start: todayStr(),
      city: $("sCity").value, housing: $("sHousing").value,
      pocket, level: parseFloat($("sLevel").value),
      history: [], pending: [], waits: 0, deposits: []
    };
    save();
    show();
  });

  /* ---------- desenarea ---------- */
  function render() {
    const dc = dayCost(), sv = savedLei(), tg = target(), n = dayNum(), N = CONFIG.ZILE_PROVOCARE;

    // antet + țintă
    $("cityTag").textContent = S.city + ", " + housingText();
    $("dayPill").textContent = n > N ? "Provocare încheiată" : "Ziua " + n + " din " + N;
    $("goalBig").textContent = fmt(sv) + " din " + fmt(tg) + " lei";
    $("goalBar").style.width = Math.min(100, (sv / tg) * 100) + "%";
    $("goalText").textContent = sv >= tg
      ? "Ți-ai atins ținta! Ai strâns " + inDays(sv) + " de student în " + S.city + "."
      : "Ai strâns " + inDays(sv) + " de student în " + S.city + ". Ținta: " + inDays(tg) + ".";

    // Orașul meu
    $("city").value = S.city; $("housing").value = S.housing;
    $("pocket").value = S.pocket; $("level").value = S.level.toFixed(2);
    $("dayCost").textContent = fmt(dc);
    $("monthNote").textContent = "O lună de student în " + S.city + " (" + housingText() + ") costă aproximativ " +
      fmt(monthCost()) + " lei. Un an universitar (10 luni) înseamnă " + fmt(monthCost() * 10) +
      " lei, fără taxa de școlarizare.";

    renderConverter();
    renderPending();
    renderHistory();
    renderCalendar();
    renderMessages();
    renderWall();
    renderReport();
    $("summary").textContent = summary();
  }

  /* ---------- raportul personal ---------- */
  const deposited = () => S.deposits.reduce((s, d) => s + d.p, 0);
  const myCode = () => CONFIG.PREFIX_COD + S.id;
  function saveEvents() {
    return S.history.filter((h) => h.a === "save").map((h) => [ZDS.dateStr(new Date(h.t || Date.now())), h.p]);
  }
  function renderReport() {
    const sv = savedLei(), dep = deposited(), rest = Math.max(0, sv - dep);
    $("myStats").className = "stats four";
    $("myStats").innerHTML = "";
    [["Pus deoparte", fmt(sv) + " lei"], ["Depus la bancă", fmt(dep) + " lei"],
     ["Încă de depus", fmt(rest) + " lei"], ["Zile de student", fmt(sv / dayCost(), 1)]].forEach(([t, v]) => {
      const d = document.createElement("div");
      const b = document.createElement("b"); b.textContent = v;
      d.append(b, t);
      $("myStats").appendChild(d);
    });
    const ev = saveEvents(), dv = S.deposits.map((d) => [d.d, d.p]);
    let to = ZDS.dateStr();
    ev.concat(dv).forEach(([d]) => { if (d > to) to = d; });
    const from = S.start < to ? S.start : to;
    ZDS.chart($("myChart"), [
      { name: "Pus deoparte", color: "var(--cobalt)", fill: true, points: ZDS.cumulative(ev, from, to) },
      { name: "Depus la bancă", color: "var(--ok)", points: ZDS.cumulative(dv, from, to) }
    ], { label: "Evoluția economiilor mele" });
    $("myNote").textContent = rest > 0
      ? "Mai ai " + fmt(rest) + " lei de dus la bancă. Doar banii depuși pot fi verificați de echipă."
      : (sv > 0 ? "Tot ce ai pus deoparte e depus la bancă. Bravo!" : "Când pui ceva deoparte, apare aici.");

    $("bankHow").textContent = "Pune banii strânși în contul tău personal de la " + CONFIG.BANCA_NUME +
      " (la ghișeu, la bancomat sau din aplicația băncii). Ca echipa să poată verifica depunerea, scrie codul tău la detaliile plății.";
    $("myCode").textContent = myCode();
    if (!$("depDate").value) $("depDate").value = ZDS.dateStr();
    $("deposits").innerHTML = "";
    S.deposits.slice().reverse().forEach((d) => {
      const b = btn("Șterge", "", { del: d.t });
      $("deposits").appendChild(li(ZDS.shortDate(d.d) + " · " + fmt(d.p, d.p % 1 ? 2 : 0) + " lei" + (d.r ? " · ref. " + d.r : ""), b));
    });
  }

  $("bDeposit").onclick = () => {
    const p = Math.round((parseFloat($("depSum").value) || 0) * 100) / 100;
    const d = $("depDate").value || ZDS.dateStr();
    if (!(p > 0)) { $("depToast").textContent = "Scrie suma depusă."; $("depSum").focus(); return; }
    if (d > ZDS.dateStr()) { $("depToast").textContent = "Data nu poate fi în viitor."; return; }
    S.deposits.push({ d, p, r: $("depRef").value.trim().slice(0, 40), t: Date.now() });
    S.deposits.sort((a, b) => (a.d < b.d ? -1 : a.d > b.d ? 1 : a.t - b.t));
    $("depSum").value = ""; $("depRef").value = "";
    $("depToast").textContent = "Notat. Echipa o va verifica în extrasul băncii.";
    save(); render();
  };
  $("deposits").addEventListener("click", (e) => {
    const b = e.target.closest("button[data-del]");
    if (!b) return;
    S.deposits = S.deposits.filter((d) => String(d.t) !== b.dataset.del);
    save(); render();
  });
  $("bCopyCode").onclick = async () => {
    try { await navigator.clipboard.writeText(myCode()); $("depToast").textContent = "Am copiat codul."; }
    catch (e) { $("depToast").textContent = "Codul tău: " + myCode(); }
  };

  function renderConverter() {
    const p = Math.max(0, parseFloat($("price").value) || 0);
    $("verdict").textContent = inDays(p);
    $("verdictCity").textContent = "de student în " + S.city + ", " + housingText();
  }

  function renderPending() {
    const now = Date.now(), wait = CONFIG.ORE_ASTEPTARE * ORA;
    const ready = [], waiting = [];
    S.pending.forEach((h, i) => (now - h.t >= wait ? ready : waiting).push([h, i]));

    $("readyBox").hidden = !ready.length;
    $("readyList").innerHTML = "";
    ready.forEach(([h, i]) => {
      const acts = document.createElement("span"); acts.className = "acts";
      acts.append(btn("Nu-l mai vreau", "gold", { i, a: "save" }), btn("Îl cumpăr", "", { i, a: "buy" }));
      $("readyList").appendChild(li(h.n + " · " + fmt(h.p) + " lei = " + inDays(h.p), acts));
    });

    $("pendingBox").hidden = !S.pending.length;
    $("pending").innerHTML = "";
    S.pending.forEach((h, i) => {
      const left = Math.ceil((h.t + wait - now) / ORA);
      const acts = document.createElement("span"); acts.className = "acts";
      if (left > 0) {
        acts.append(btn("Renunț deja", "gold", { i, a: "save" }));
        $("pending").appendChild(li(h.n + " · " + inDays(h.p) + " · mai ai " + (left === 1 ? "o oră" : left + " ore"), acts));
      } else {
        acts.append(btn("Nu-l mai vreau", "gold", { i, a: "save" }), btn("Îl cumpăr", "", { i, a: "buy" }));
        $("pending").appendChild(li(h.n + " · " + inDays(h.p) + " · poți decide", acts));
      }
    });
  }

  function renderHistory() {
    const c = (a) => S.history.filter((h) => h.a === a).length;
    $("stats").innerHTML = "";
    [["Puse deoparte", c("save")], ["Cumpărate", c("buy")], ["Așteptate 24 h", S.waits || 0]].forEach(([t, v]) => {
      const d = document.createElement("div");
      const b = document.createElement("b"); b.textContent = v;
      d.append(b, t);
      $("stats").appendChild(d);
    });
    $("history").innerHTML = "";
    if (!S.history.length) {
      const e = li("Încă nimic. Scrie un preț mai sus și alege ce faci.");
      e.firstChild.className = "note";
      $("history").appendChild(e);
    }
    S.history.slice().reverse().forEach((h) => {
      const pill = document.createElement("span");
      pill.className = "pill " + (h.a === "save" ? "p-save" : "p-buy");
      pill.textContent = h.a === "save" ? "Pus deoparte" : "Cumpărat";
      $("history").appendChild(li(h.n + " · " + fmt(h.p) + " lei = " + inDays(h.p), pill));
    });
  }

  function renderCalendar() {
    const full = savedLei() / dayCost();
    $("calNote").textContent = "Fiecare " + fmt(dayCost()) + " lei puși deoparte colorează o zi din primul tău an în " +
      S.city + ". Până acum: " + inDays(savedLei()) + " din 300.";
    const box = $("months");
    box.innerHTML = "";
    let idx = 0;
    LUNI.forEach((name) => {
      const row = document.createElement("div"); row.className = "month";
      const b = document.createElement("b"); b.textContent = name;
      const g = document.createElement("div"); g.className = "days";
      for (let i = 0; i < 30; i++, idx++) {
        const d = document.createElement("i"); d.className = "d";
        if (idx + 1 <= full) d.classList.add("full");
        else if (idx < full) {
          const p = document.createElement("i"); p.className = "part";
          p.style.height = (full - idx) * 100 + "%";
          d.appendChild(p);
        }
        d.title = "Ziua " + (idx + 1) + " din anul I";
        g.appendChild(d);
      }
      row.append(b, g);
      box.appendChild(row);
    });
  }

  function renderMessages() {
    const n = dayNum(), N = CONFIG.ZILE_PROVOCARE;
    const open = MESAJE.filter((m) => m.zi <= n).sort((a, b) => b.zi - a.zi);
    const next = MESAJE.filter((m) => m.zi > n).sort((a, b) => a.zi - b.zi)[0];
    const box = $("msgs");
    box.innerHTML = "";
    if (next || n < N) {
      const m = document.createElement("div"); m.className = "msg locked";
      m.textContent = next ? "Următorul mesaj vine în ziua " + next.zi + "." : "Scrisoarea ta vine în ziua " + N + ".";
      box.appendChild(m);
    }
    open.forEach((msg, i) => {
      if (i >= 3 && !showAll) return;
      const m = document.createElement("div");
      m.className = "msg" + (i === 0 ? " new" : "");
      const f = document.createElement("span"); f.className = "from";
      f.textContent = "Ziua " + msg.zi + " · de la tine, student în " + S.city;
      const t = document.createElement("span"); t.textContent = fill(msg.text);
      m.append(f, t);
      box.appendChild(m);
    });
    if (open.length > 3 && !showAll) {
      const more = btn("Vezi mesajele mai vechi (" + (open.length - 3) + ")", "", {});
      more.onclick = () => { showAll = true; renderMessages(); };
      box.appendChild(more);
    }

    $("letterBox").hidden = n < N;
    if (n >= N) {
      const sv = savedLei(), tg = target();
      $("letter").textContent =
        "Dragă eu de acum,\n\nÎți scriu din " + S.city + ", din primul an. În cele " + N + " de zile ai pus deoparte " +
        fmt(sv) + " lei, adică " + inDays(sv) + " din viața mea de aici." +
        (sv >= tg ? " Ți-ai atins ținta. " : " Nu ți-ai atins încă ținta, dar ai început, și asta contează cel mai mult. ") +
        "\n\nPrimul an mă costă cam " + fmt(monthCost() * 10) + " lei. Nu trebuie să-i strângi pe toți acum. Trebuie doar să nu te oprești." +
        "\n\nCu drag,\ntu, student";
    }
  }

  function renderWall() {
    const st = STATISTICI_LICEU, goal = CONFIG.LICEU_OBIECTIV;
    $("wallN").textContent = fmt(st.zile, st.zile % 1 ? 1 : 0);
    $("wallT").textContent = "zile de facultate strânse de " + (st.participanti || CONFIG.NR_ELEVI) + " de elevi. Obiectivul comun: " +
      goal + " de zile, un an întreg.";
    $("wallBar").style.width = Math.min(100, (st.zile / goal) * 100) + "%";
    const hasSeries = st.serie && st.serie.length > 0;
    $("wallChart").hidden = !hasSeries;
    if (hasSeries) {
      ZDS.chart($("wallChart"), [
        { name: "Declarat", color: "var(--cobalt)", fill: true, points: st.serie.map((r) => [r[0], r[1]]) },
        { name: "Verificat la bancă", color: "var(--ok)", points: st.serie.map((r) => [r[0], r[2]]) }
      ], { label: "Evoluția economiilor tuturor elevilor", height: 170 });
    }
    $("wallNote").textContent = (st.actualizat
      ? "Actualizat: " + st.actualizat + ". În total: " + fmt(st.declarat) + " lei puși deoparte, din care " + fmt(st.verificat) + " lei verificați la bancă. "
      : "Totalul apare după primele rapoarte trimise. ") +
      "Contribuția ta: " + inDays(savedLei()) + "." +
      (canStore ? "" : " Atenție: browserul tău nu salvează datele, folosește alt browser.");
  }

  function reportData() {
    const c = (a) => S.history.filter((h) => h.a === a).length;
    return {
      i: S.id, c: S.city, h: S.housing, s: S.start, d: ZDS.dateStr(),
      p: S.pocket, g: target(), z: Math.round(dayCost() * 100) / 100,
      e: saveEvents(), b: S.deposits.map((d) => [d.d, d.p, d.r || ""]),
      k: [c("buy"), S.waits || 0]
    };
  }
  function summary() {
    const c = (a) => S.history.filter((h) => h.a === a).length;
    const sv = savedLei();
    const n = Math.min(dayNum(), CONFIG.ZILE_PROVOCARE);
    return [
      "Zile de student · raport",
      "Cod: " + myCode(),
      "Oraș: " + S.city + ", " + housingText(),
      "Ziua: " + n + " din " + CONFIG.ZILE_PROVOCARE,
      "Pus deoparte: " + fmt(sv) + " lei (" + fmt(sv / dayCost(), 2) + " zile)",
      "Depus la bancă: " + fmt(deposited()) + " lei",
      "Ținta: " + fmt(target()) + " lei (" + (sv >= target() ? "atinsă" : "neatinsă") + ")",
      "Decizii: " + c("save") + " puse deoparte, " + c("buy") + " cumpărate, " + (S.waits || 0) + " așteptate 24 h",
      "",
      ZDS.encode(reportData())
    ].join("\n");
  }

  /* ---------- acțiuni ---------- */
  function act(a) {
    const p = Math.round((parseFloat($("price").value) || 0) * 100) / 100;
    const n = $("item").value.trim() || "Ceva";
    if (!(p > 0)) { $("toast").textContent = "Scrie mai întâi prețul."; $("price").focus(); return; }
    if (a === "wait") {
      S.pending.push({ n, p, t: Date.now() });
      S.waits = (S.waits || 0) + 1;
      $("toast").textContent = "Bine. Mâine, la aceeași oră, te întreb dacă mai vrei „" + n + "”.";
    } else {
      S.history.push({ n, p, a, t: Date.now() });
      $("toast").textContent = a === "save"
        ? "Ai pus deoparte " + inDays(p) + " de student. Uită-te în calendar!"
        : "Notat: " + n + ", " + inDays(p) + ".";
    }
    $("item").value = ""; $("price").value = "";
    save(); render();
  }
  $("bBuy").onclick = () => act("buy");
  $("bWait").onclick = () => act("wait");
  $("bSave").onclick = () => act("save");
  $("price").addEventListener("input", renderConverter);

  function decide(e) {
    const b = e.target.closest("button[data-a]");
    if (!b) return;
    const h = S.pending.splice(+b.dataset.i, 1)[0];
    if (!h) return;
    S.history.push({ n: h.n, p: h.p, a: b.dataset.a, t: Date.now() });
    $("toast").textContent = b.dataset.a === "save" ? "Bravo. " + inDays(h.p) + " în plus în calendar." : "Notat.";
    save(); render();
  }
  $("pending").addEventListener("click", decide);
  $("readyList").addEventListener("click", decide);

  ["city", "housing", "pocket", "level"].forEach((id) => $(id).addEventListener("change", () => {
    S.city = $("city").value;
    S.housing = $("housing").value;
    S.pocket = Math.max(1, Math.round(+$("pocket").value) || S.pocket);
    S.level = +$("level").value;
    save(); render();
  }));

  async function sendResult(toastId) {
    const text = summary();
    $("summary").textContent = text;
    let ok = false;
    try { await navigator.clipboard.writeText(text); ok = true; } catch (e) { /* fără clipboard */ }
    if (!ok) {
      const r = document.createRange(); r.selectNodeContents($("summary"));
      const s = getSelection(); s.removeAllRanges(); s.addRange(r);
      try { ok = document.execCommand("copy"); } catch (e) { /* nimic */ }
    }
    if (CONFIG.LINK_FORMULAR) {
      window.open(CONFIG.LINK_FORMULAR, "_blank", "noopener");
      $(toastId).textContent = ok ? "Am copiat raportul. Lipește-l în formularul care s-a deschis." : "Copiază textul din fila „Raport” și lipește-l în formular.";
    } else {
      $(toastId).textContent = ok ? "Am copiat raportul. Trimite-l echipei proiectului." : "Copiază textul din fila „Raport” și trimite-l echipei.";
    }
  }
  $("bResult").onclick = () => { $("summary").textContent = summary(); sendResult("resultToast"); };
  $("bResult2").onclick = () => sendResult("resultToast2");

  let resetArmed = false;
  $("bReset").onclick = () => {
    if (!resetArmed) {
      resetArmed = true;
      $("bReset").textContent = "Sigur? Apasă din nou ca să ștergi tot";
      setTimeout(() => { resetArmed = false; $("bReset").textContent = "Șterge datele mele"; }, 5000);
      return;
    }
    try { localStorage.removeItem(KEY); } catch (e) { /* nimic */ }
    S = null; resetArmed = false;
    $("bReset").textContent = "Șterge datele mele";
    show();
  };

  /* ---------- file (tab-uri) ---------- */
  function openTab(id) {
    document.querySelectorAll(".tabs button").forEach((x) => x.setAttribute("aria-selected", x.dataset.t === id));
    document.querySelectorAll(".panel").forEach((p) => (p.hidden = p.id !== id));
    window.scrollTo(0, 0);
  }
  document.querySelectorAll(".tabs button").forEach((b) => (b.onclick = () => openTab(b.dataset.t)));

  function show() {
    const started = !!(S && S.start);
    $("start").hidden = started;
    $("main").hidden = !started;
    $("tabs").hidden = !started;
    if (started) { render(); openTab("p-azi"); }
  }

  // Reîmprospătează când elevul revine în aplicație (de ex. a doua zi).
  document.addEventListener("visibilitychange", () => { if (!document.hidden && S && S.start) render(); });
  setInterval(() => { if (S && S.start && !document.hidden) renderPending(); }, 60 * 1000);

  show();
})();
