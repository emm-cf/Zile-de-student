# Zile de student: cum publici site-ul

Site-ul e format doar din fișiere (HTML, CSS, JavaScript). Nu are nevoie de server, de bază de date sau de bani. Datele fiecărui elev se salvează doar în browserul de pe telefonul lui.

## Ce e în folder

| Fișier | Ce face |
|---|---|
| `index.html` | Aplicația elevilor |
| `echipa.html` | Pagina echipei: verificarea depunerilor și raportul pe toți elevii |
| `css/style.css`, `css/echipa.css` | Culorile și aspectul |
| `js/date.js` | **Fișierul pe care îl schimbă echipa**: numele băncii, linkul formularului, statisticile liceului, costurile orașelor, mesajele |
| `js/app.js`, `js/echipa.js`, `js/comun.js` | Logica (nu trebuie atinsă) |
| `icon.svg`, `manifest.webmanifest` | Iconița și opțiunea „Adaugă pe ecranul principal” |

## Varianta 1: Netlify Drop (cea mai simplă, 2 minute)

1. Intră pe **app.netlify.com/drop** de pe un calculator.
2. Trage tot folderul `zile-de-student` în chenarul de pe pagină.
3. Primești imediat un link de forma `https://nume-ciudat.netlify.app`. Site-ul e deja public.
4. Ca să nu dispară după o oră, fă-ți cont gratuit (butonul „Claim” sau „Sign up”) și revendică site-ul.
5. Din **Site configuration → Change site name** îl poți redenumi, de exemplu `zile-de-student-liceul-x.netlify.app`.

Când schimbi ceva (de exemplu totalul liceului): intri pe site în Netlify, fila **Deploys**, și tragi din nou folderul acolo.

## Varianta 2: GitHub Pages

1. Fă-ți cont gratuit pe **github.com**.
2. Apasă **New repository**, numește-l `zile-de-student`, alege **Public** și apasă **Create repository**.
3. Apasă **uploading an existing file** și trage înăuntru **conținutul** folderului (`index.html`, `echipa.html`, `css`, `js`, `icon.svg`, `manifest.webmanifest`), nu folderul însuși. Apasă **Commit changes**.
4. Mergi la **Settings → Pages**. La „Branch” alege `main` și `/ (root)`, apoi **Save**.
5. După 1–2 minute, site-ul apare la `https://numele-tau.github.io/zile-de-student/`.

Când schimbi ceva: deschizi fișierul pe GitHub, apeși pe creionul de editare, modifici și apeși **Commit changes**. Site-ul se actualizează singur în câteva minute.

## Înainte de lansare (pentru echipă)

1. **Banca parteneră.** Stabiliți cu banca: fiecare elev își deschide un cont personal (sub 18 ani, de obicei cu acordul unui părinte), iar banca vă trimite o dată pe săptămână un extras CSV doar cu depunerile în conturile participanților, cu acordul scris al elevilor și al părinților. În `js/date.js`, scrieți numele băncii la `BANCA_NUME`.
2. **Formularul.** Faceți un Google Form cu o singură întrebare de tip paragraf: „Lipește aici raportul tău”. Puneți linkul la `LINK_FORMULAR` în `js/date.js`.
3. Testați site-ul pe 2–3 telefoane (Android și iPhone) și faceți un cod QR cu linkul.

## Cum se verifică economiile

**Elevul**, în aplicație:
1. Apasă „Pun deoparte” când renunță la o cumpărătură. Asta e suma **declarată**.
2. Depune banii în contul lui de la banca parteneră și scrie la „detalii plată” **codul lui** (de exemplu `ZDS-AB12CD`, îl vede în fila „Raport”).
3. Notează depunerea în fila „Raport” → „Am depus banii” (suma, data și, dacă are, referința de pe chitanță).
4. O dată pe săptămână apasă „Trimite raportul” și lipește textul în formular.

**Echipa**, o dată pe săptămână, pe `echipa.html` (de pe calculator):
1. Descarcă răspunsurile din Google Forms (Răspunsuri → ⋮ → Descarcă răspunsurile CSV) și încarcă fișierul la pasul 1.
2. Încarcă extrasul CSV de la bancă la pasul 2. Verifică dacă pagina a ales bine coloanele cu data și suma.
3. Pagina compară automat. Un rând din extras aparține unui elev dacă în el apare codul lui sau referința declarată de el. Fiecare elev primește o stare:
   - **verificat**: toți banii puși deoparte se găsesc la bancă;
   - **parțial depus** sau **nedepus încă**: a pus deoparte mai mult decât a depus;
   - **declarat, negăsit la bancă**: spune că a depus, dar depunerea nu apare în extras. Pe aceștia îi întrebați personal.
4. Ce primiți: totalurile pentru toți elevii (declarat față de verificat), graficul evoluției pe zile, tabelul cu fiecare elev și, la click pe un rând, raportul individual cu graficul lui și fiecare depunere marcată „găsită” sau „negăsită”. Puteți descărca tabelul (CSV, se deschide în Excel) sau printa raportul ca PDF.
5. Apăsați „Copiază statisticile pentru site”. În `js/date.js`, înlocuiți tot blocul `const STATISTICI_LICEU = { … };` cu ce ați copiat și publicați din nou. Elevii vor vedea în fila „Azi” totalul liceului și graficul comun.

**Date de exemplu:** pe `echipa.html`, butonul „Încarcă date de exemplu” umple pagina cu 100 de elevi inventați și un extras inventat, ca să puteți prezenta raportul înainte de rezultatele reale. „Descarcă fișierele de exemplu” vă arată cum arată cele două fișiere.

**Confidențialitate:** `echipa.html` citește fișierele doar în browser, nu le trimite nicăieri și nu le salvează. Nu puneți niciodată extrasul băncii sau răspunsurile din formular în folderul site-ului. Pe site ajung doar totalurile.

## Cum ar arăta integrarea reală cu banca

Varianta de mai sus e manuală (extras CSV o dată pe săptămână), pentru că un proiect școlar nu are server. O versiune adevărată ar funcționa așa:

1. **Open Banking (directiva europeană PSD2).** Băncile din România au obligația să ofere acces la informațiile din cont prin API, cu acordul titularului. Elevul (și părintele, dacă e minor) apasă în aplicație „Conectează contul” și își dă acordul direct pe pagina băncii, pentru 90 de zile, doar pentru citirea tranzacțiilor.
2. **Un mic server** (de exemplu o funcție în cloud) primește de la bancă, zilnic, depunerile din contul de economii al fiecărui participant. Serverul e necesar pentru că accesul la API se face cu chei care nu pot sta pe un site public.
3. **Verificarea devine automată:** fiecare „Pun deoparte” din aplicație se potrivește cu depunerea reală, iar elevul vede bifa „verificat” chiar în aplicație, fără formular.
4. **Contorul liceului se actualizează singur**, din aceeași bază de date, fără să republicați site-ul.
5. **Condiții:** acord scris al părinților, prelucrarea datelor conform GDPR (doar sumele și datele depunerilor, nu tot istoricul contului) și un contract cu banca sau cu un furnizor autorizat de servicii de informare cont.

## Pentru prezentare

Pe `echipa.html`, apasă „Încarcă date de exemplu” ca să arăți raportul pe 100 de elevi și verificarea prin bancă.

Adaugă `?zi=30` la finalul adresei (de exemplu `https://.../?zi=30`) ca să arăți cum arată aplicația în ziua 30, cu scrisoarea finală. Merge cu orice zi, de la 1 la 30. Nu schimbă datele salvate.

## Bine de știut

- Datele rămân pe telefonul elevului. Dacă își șterge istoricul browserului sau schimbă telefonul, pierde progresul. Spuneți-le asta la început.
- Fiecare telefon e independent, deci nu există conturi și parole.
- Costurile orașelor vin din calculatorul „Facultatea mea” (foaia „Comparatie”, curs BNR 19.11.2026). Dacă actualizați calculatorul, schimbați și cifrele din `js/date.js`.
- Mesajele de la „tine, student” se pot rescrie tot în `js/date.js`. Păstrați acoladele, de exemplu `{oras}`, pentru că acolo apar cifrele elevului.
